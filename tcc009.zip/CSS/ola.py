from datetime import datetime

hora = int(datetime.now().strftime("%H"))
if hora > 0 and hora < 13:
    print("bom dia")
elif(hora >= 13 and hora <= 17):
    print("boa tarde")
else:
    print("boa noite")


