<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="./CSS/adimin.css">
    <link rel="stylesheet" href="./bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <script src="./bootstrap-5.3.3-dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="./fontawesome-free-6.5.2-web/css/all.min.css">
    <script src="./fontawesome-free-6.5.2-web/js/all.min.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php include 'header.php';?>
    <div style="height:120px; "></div>
    <section>
        <div class="conteiner-funcionario">
            <div class="funcionario">
                <div class="bolabrnaca-usu">
                    <i class="usu fa-solid fa-user"></i>
                </div> 
                <div class="info-funcionario">
                    <div>Nome: carlos </div>
                    <div> Nivel de acesso: 2</div>
                    <div> telefone:xxxxxxxx</div>
                </div>
            </div>
            <div class="funcionario">
                <div class="bolabrnaca-usu">
                    <i class="usu fa-solid fa-user"></i>
                </div> 
                <div class="info-funcionario">
                    <div>Nome: carlos </div>
                    <div> Nivel de acesso: 2</div>
                    <div> telefone:xxxxxxxx</div>
                </div>
            </div>
            <div class="funcionario">
                <div class="bolabrnaca-usu">
                    <i class="usu fa-solid fa-user"></i>
                </div> 
                <div class="info-funcionario">
                    <div>Nome: carlos </div>
                    <div> Nivel de acesso: 2</div>
                    <div> telefone:xxxxxxxx</div>
                </div>
            </div>
            <div class="funcionario">
                <div class="bolabrnaca-usu">
                    <i class="usu fa-solid fa-user"></i>
                </div> 
                <div class="info-funcionario">
                    <div>Nome: carlos </div>
                    <div> Nivel de acesso: 2</div>
                    <div> telefone:xxxxxxxx</div>
                </div>
            </div>
        </div>
    </section>
</body>
</html>